package com.cts.contract.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.contract.model.Requirement;
import com.cts.contract.service.RequirementService;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class RequirementController 
{
	@Autowired
	RequirementService requirementService;
	
	@GetMapping("/requirements")
	public List<Requirement> getAllRequirements()
	{		
		return requirementService.getAllRequirements();
	}
	
	@GetMapping("/requirements/id/{req_id}")
	public Optional<Requirement> getRequirementById(@PathVariable Integer req_id)
	{
		return requirementService.getRequirementById(req_id);
		
	}
	
	/*@GetMapping("/requirements/{req_type}")
	public List<Requirement> getRequirementByName(@PathVariable String req_type)
	{
		return requirementService.getRequirementByType(req_type);
		
	}*/
	
	@PostMapping("/requirements")
	public Requirement saveRequirement(@RequestBody Requirement requirement)
	{
		
		return requirementService.saveRequirement(requirement);
	}
	
	@PutMapping("/requirements/{req_id}")
	public Requirement updateRequirement(@PathVariable("req_id") Integer req_id,@RequestBody Requirement requirement)
	{
		
		return requirementService.updateRequirement(req_id, requirement);
	}
	
	
	@DeleteMapping("/requirements/{id}")
	public boolean deleteRequirementById(@PathVariable Integer id)
	{
		
		return requirementService.deleteRequirementById(id);
		
	}

}
