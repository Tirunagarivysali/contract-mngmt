package com.cts.contract.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="requirement_table")
public class Requirement 
{
	@Id
	@GeneratedValue
	private int req_id;
	private String req_type;
	private String req_des;
	private String expected_delivery_date;
	public int getReq_id() {
		return req_id;
	}
	public void setReq_id(int req_id) {
		this.req_id = req_id;
	}
	public String getReq_type() {
		return req_type;
	}
	public void setReq_type(String req_type) {
		this.req_type = req_type;
	}
	public String getReq_des() {
		return req_des;
	}
	public void setReq_des(String req_des) {
		this.req_des = req_des;
	}
	public String getExpected_delivery_date() {
		return expected_delivery_date;
	}
	public void setExpected_delivery_date(String expected_delivery_date) {
		this.expected_delivery_date = expected_delivery_date;
	}


}
