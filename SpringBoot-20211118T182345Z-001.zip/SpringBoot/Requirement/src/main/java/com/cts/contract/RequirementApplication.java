package com.cts.contract;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RequirementApplication {

	public static void main(String[] args) {
		SpringApplication.run(RequirementApplication.class, args);
	}

}
