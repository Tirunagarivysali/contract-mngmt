package com.cts.contract.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.contract.model.Requirement;



public interface RequirementRepository extends JpaRepository<Requirement, Integer> 
{
	//List<Requirement> findByName(String name);
	
	List<Requirement> findById(int id);
}
