package com.cts.contract.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.contract.dao.RequirementRepository;
import com.cts.contract.model.Requirement;


@Service
public class RequirementService 
{
	@Autowired
	RequirementRepository requirementRepository;
	public RequirementService()
	{
		
	}
	
	public List<Requirement> getAllRequirements()
	{
		
		return requirementRepository.findAll();
	}
	
	public Optional<Requirement> getRequirementById(Integer id)
	{
		 return requirementRepository.findById(id);
		
	}
	
	/*public List<Requirement> getRequirementByType(String name)
	{
		 return requirementRepository.findByName(name);
		
	}*/
	
	
	
	public Requirement saveRequirement(@RequestBody Requirement requirement)
	{
		return  requirementRepository.save(requirement);
	}
	
	public Requirement updateRequirement(Integer id,Requirement requirement)
	{
		List<Requirement> r=getAllRequirements();
		int position=0;
		for(Requirement req:r)
		{
			if(req.getReq_id()==id) 
			{
				req.setReq_id(id);
				req.setReq_type(requirement.getReq_type());
				req.setReq_des(requirement.getReq_des());
				req.setExpected_delivery_date(requirement.getExpected_delivery_date());
				
				requirementRepository.save(req);
				r.set(position, req);
				
				break;
				
			}
			position++;
			
			
		}
		
		return requirement;
	}
	
	public boolean deleteRequirementById(Integer id)
	{
		if(requirementRepository.getById(id)!=null) {
			requirementRepository.deleteById(id);
		return true;
		}
		else
		{
			return false;
		}
		
	}
}
