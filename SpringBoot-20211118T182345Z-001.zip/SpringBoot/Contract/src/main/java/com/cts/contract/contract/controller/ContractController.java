package com.cts.contract.contract.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.contract.contract.model.Contract;
import com.cts.contract.contract.service.ContractService;





@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ContractController {
	
	@Autowired
	ContractService contractService;	
	
	
	@GetMapping("/contracts")
	public List<Contract> getAllContracts()
	{		
		return contractService.getAllContracts();
	}
	
	@GetMapping("/contracts/id/{contract_id}")
	public Contract getContractById(@PathVariable Integer contract_id)
	{
	return contractService.getContractById(contract_id);


	}
	
	@GetMapping("/contracts/{type}")
	public List<Contract> getContractByType(@PathVariable String type)
	{
	return contractService.getContractByType(type);

	}

	
	
	@PostMapping("/contracts")
	public Contract saveContract(@RequestBody Contract contract)
	{
		
		return contractService.saveContract(contract);
	}
	
	@PutMapping("/contracts/{id}")
	public Contract updateContract(@PathVariable("id") Integer id,@RequestBody Contract contract) throws Exception
	{
		
		return contractService.updateContract(id, contract);
			
	}
	
	@PutMapping("/contracts/edit/{id}")
	public Contract updateEditContract(@PathVariable("id") Integer id,@RequestBody Contract contract) throws Exception
	{
		
		return contractService.updateEditContract(id, contract);
			
	}
	
	
	@PutMapping("/contracts/status/{id}")
	public Contract updateContractStatus(@PathVariable("id") Integer id,@RequestBody Contract contract) throws Exception
	{
		
		return contractService.updateContractStatus(id, contract);
			
	}

	
	@DeleteMapping("/contract/{id}")
	public boolean deleteContractById(@PathVariable Integer id)
	{
		
		return contractService.deleteContractById(id);
		
	}

}
