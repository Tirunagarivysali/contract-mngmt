package com.cts.contract.contract.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.contract.contract.dao.ContractDao;
import com.cts.contract.contract.model.Contract;


@Service
public class ContractService {
	
	@Autowired
	ContractDao contractDao;	
	
	public ContractService()
	{
		
	}
	
	
	public List<Contract> getAllContracts()
	{
		
		return contractDao.findAll();
	}
	

	
	public Contract getContractById(Integer id)
	{
	return contractDao.findById(id).orElse(null);

	}
	
	
	public List<Contract> getContractByType(String type)
	{
	return contractDao.findByContractType(type);

	}

	
	
	
	
	public Contract saveContract(@RequestBody Contract contract)
	{
		return  contractDao.save(contract);
	}
	
	
	public Contract updateContract(Integer id,Contract contract)
	{
	List<Contract> c=getAllContracts();
	int position=0;
	for(Contract con:c)
	{
	if(con.getContractId()==id)
	{
		con.setContractId(id);
		con.setContractType(con.getContractType());
		con.setContractDuration(con.getContractDuration());
		con.setAmenities(contract.getAmenities());
		contractDao.save(con);
		c.set(position, con);
	
		break;

	}
	position++;


	}

	return contract;
	}
	
	public Contract updateEditContract(Integer id,Contract contract)
	{
	List<Contract> c=getAllContracts();
	int position=0;
	for(Contract con:c)
	{
	if(con.getContractId()==id)
	{
		con.setContractId(id);
		con.setContractType(contract.getContractType());
		con.setContractDuration(contract.getContractDuration());
		con.setAmenities(con.getAmenities());
		contractDao.save(con);
		c.set(position, con);
	
		break;

	}
	position++;


	}

	return contract;
	}
	
	public boolean deleteContractById(Integer id)
	{
		if(contractDao.getById(id)!=null) {
			contractDao.deleteById(id);
		return true;
		}
		else
		{
			return false;
		}
		
	}
	
	public Contract updateContractStatus(Integer id,Contract contract)
	{
	List<Contract> c=getAllContracts();
	int position=0;
	for(Contract con:c)
	{
	if(con.getContractId()==id)
	{
		con.setContractId(id);
		con.setContractType(con.getContractType());
		con.setContractDuration(con.getContractDuration());
		con.setAmenities(con.getAmenities());
		con.setContract_status(contract.getContract_status());
		contractDao.save(con);
		c.set(position, con);
	
		break;

	}
	position++;


	}

	return contract;
	}

}
