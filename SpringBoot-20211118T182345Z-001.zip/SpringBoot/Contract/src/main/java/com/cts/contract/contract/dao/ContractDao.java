package com.cts.contract.contract.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.contract.contract.model.Contract;





public interface ContractDao extends JpaRepository<Contract, Integer>{
	
	
	
	List<Contract> findById(int id);
	
	List<Contract> findByContractType(String type);
	
	List<Contract> findByContractId(Integer contractId);

}
