package com.cts.contract.proposal.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.contract.proposal.model.Proposal;

public interface ProposalDao extends JpaRepository<Proposal, Integer> {

	List<Proposal> findById(int id);
	
}
