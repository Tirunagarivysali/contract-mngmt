package com.cts.contract.proposal.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="proposal_table")
public class Proposal {

@Id
@GeneratedValue
private int proposal_id;
private int requirement_id;
private String proposal_date;
private String quotation;
private String supplier_name;
private String proposal_status;

public int getProposal_id() {
	return proposal_id;
}
public void setProposal_id(int proposal_id) {
	this.proposal_id = proposal_id;
}
public int getRequirement_id() {
	return requirement_id;
}
public void setRequirement_id(int requirement_id) {
	this.requirement_id = requirement_id;
}
public String getProposal_date() {
	return proposal_date;
}
public void setProposal_date(String proposal_date) {
	this.proposal_date = proposal_date;
}
public String getQuotation() {
	return quotation;
}
public void setQuotation(String quotation) {
	this.quotation = quotation;
}
public String getSupplier_name() {
	return supplier_name;
}
public void setSupplier_name(String supplier_name) {
	this.supplier_name = supplier_name;
}
public String getProposal_status() {
	return proposal_status;
}
public void setProposal_status(String proposal_status) {
	this.proposal_status = proposal_status;
}


}
