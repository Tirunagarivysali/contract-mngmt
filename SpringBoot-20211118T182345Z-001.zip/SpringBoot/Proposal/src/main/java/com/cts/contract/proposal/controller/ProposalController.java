package com.cts.contract.proposal.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.contract.proposal.model.Proposal;
import com.cts.contract.proposal.service.ProposalService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ProposalController {

	@Autowired
	ProposalService proposalService;
	
	@GetMapping("/proposal")
	public List<Proposal> getAllProposals()
	{		
		return proposalService.getAllProposals();
	}
	@GetMapping("/proposal/id/{proposal_id}")
	public Optional<Proposal> getProposalById(@PathVariable Integer proposal_id)
	{
	return proposalService.getProposalById(proposal_id);


	}
		
	
	@PostMapping("/proposal")
	public Proposal saveProposal(@RequestBody Proposal proposal)
	{
		
		return proposalService.saveProposal(proposal);
	}
	
	@PutMapping("/proposal/{id}")
	public Proposal updateProposal(@PathVariable("id") Integer id,@RequestBody Proposal proposal)
	{
		
		return proposalService.updateProposal(id, proposal);
	}
	
	@PutMapping("/proposal/status/{id}")
	public Proposal updateProposalStatus(@PathVariable("id") Integer id,@RequestBody Proposal proposal)
	{
		
		return proposalService.updateProposalStatus(id, proposal);
	}
	
	
	@DeleteMapping("/proposal/{id}")
	public boolean deleteProposalById(@PathVariable Integer id)
	{
		
		return proposalService.deleteProposalById(id);
		
	}

}

