package com.cts.contract.proposal.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;


import com.cts.contract.proposal.dao.ProposalDao;
import com.cts.contract.proposal.model.Proposal;

@Service
public class ProposalService {
	
@Autowired
ProposalDao proposalDao;

public ProposalService() {

}

public Optional<Proposal> getProposalById(Integer id)
{
	 return proposalDao.findById(id);
	
}
public List<Proposal> getAllProposals()
{
	
	return proposalDao.findAll();
}
	
public Proposal saveProposal(@RequestBody Proposal proposal)
{
	return proposalDao.save(proposal);
}

public Proposal updateProposal(Integer id,Proposal proposal)
{
List<Proposal> p=getAllProposals();
int position=0;
for(Proposal pro:p)
{
if(pro.getProposal_id()==id)
{
pro.setProposal_id(id);
pro.setRequirement_id(proposal.getRequirement_id());
pro.setProposal_date(proposal.getProposal_date());
pro.setQuotation(proposal.getQuotation());
proposalDao.save(pro);
p.set(position, pro);

break;

}
position++;


}

return proposal;
}
public boolean deleteProposalById(Integer id)
{
	if(proposalDao.getById(id)!=null) {
		proposalDao.deleteById(id);
	return true;
	}
	else
	{
		return false;
	}
	

}


public Proposal updateProposalStatus(Integer id,Proposal proposal)
{
List<Proposal> p=getAllProposals();
int position=0;
for(Proposal pro:p)
{
if(pro.getProposal_id()==id)
{
pro.setProposal_id(id);
pro.setRequirement_id(pro.getRequirement_id());
pro.setProposal_date(pro.getProposal_date());
pro.setQuotation(pro.getQuotation());
pro.setProposal_status(proposal.getProposal_status());
proposalDao.save(pro);
p.set(position, pro);

break;

}
position++;


}

return proposal;
}

}