package com.cts.contract.contractAdmin.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.contract.contractAdmin.dao.AdminDao;
import com.cts.contract.contractAdmin.model.ContractAdmin;



@Service
public class AdminService {
	
	@Autowired
	AdminDao adminDao;	
	
	public AdminService()
	{
		
	}
	
	
	public List<ContractAdmin> getAllAdmins()
	{
		
		return adminDao.findAll();
	}
	
	public Optional<ContractAdmin> getAdminById(Integer id)
	{
		 return adminDao.findById(id);
		
	}
	
	/*public List<ContractAdmin> getAdminByName(String name)
	{
		 return adminDao.findByName(name);
		
	}*/
	
	
	
	public ContractAdmin saveAdmin(@RequestBody ContractAdmin admin)
	{
		return  adminDao.save(admin);
	}
	
	public ContractAdmin updateAdmin(Integer id,ContractAdmin contractAdmin)
	{
	List<ContractAdmin> a=getAllAdmins();
	int position=0;
	for(ContractAdmin adm:a)
	{
	if(adm.getadmin_id()==id)
	{
	adm.setadmin_id(id);
	adm.setadmin_name(contractAdmin.getadmin_name());
	adm.setadmin_contact(contractAdmin.getadmin_contact());
	adm.setadmin_password(contractAdmin.getadmin_password());
	adm.setadmin_address(contractAdmin.getadmin_address());
	adminDao.save(adm);
	a.set(position, adm);

	break;

	}
	position++;


	}

	return contractAdmin;
	}
	public boolean deleteAdminById(Integer id)
	{
		if(adminDao.getById(id)!=null) {
			adminDao.deleteById(id);
		return true;
		}
		else
		{
			return false;
		}
		
	}

}

