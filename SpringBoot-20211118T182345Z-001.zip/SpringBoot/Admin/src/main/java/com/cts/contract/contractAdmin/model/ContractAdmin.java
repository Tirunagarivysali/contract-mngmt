package com.cts.contract.contractAdmin.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin_table")
public class ContractAdmin {

	@Id
	@GeneratedValue
	private int admin_id;
	private String admin_name;
	private String admin_contact;
	private String admin_password;
	private String admin_address;
	
	
	public int getadmin_id() {
		return admin_id;
	}
	public void setadmin_id(int admin_id) {
		this.admin_id = admin_id;
	}
	
	public String getadmin_name() {
		return admin_name;
	}
	public void setadmin_name(String admin_name) {
		this.admin_name =admin_name;
	}
	
	public String getadmin_contact() {
		return admin_contact;
	}
	public void setadmin_contact(String admin_contact) {
		this.admin_contact = admin_contact;
	}
	
	public String getadmin_password() {
		return admin_password;
	}
	public void setadmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	
	public String getadmin_address() {
		return admin_address;
	}
	public void setadmin_address(String admin_address) {
		this.admin_address = admin_address;
	}
}