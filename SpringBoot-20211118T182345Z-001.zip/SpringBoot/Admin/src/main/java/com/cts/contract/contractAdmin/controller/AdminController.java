package com.cts.contract.contractAdmin.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.contract.contractAdmin.model.ContractAdmin;
import com.cts.contract.contractAdmin.service.AdminService;



@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdminController {
	
	@Autowired
	AdminService adminService;	
	
	
	@GetMapping("/contractadmin")
	public List<ContractAdmin> getAllAdmins()
	{		
		return adminService.getAllAdmins();
	}
	
	
	@GetMapping("/contractadmin/id/{admin_id}")
	public Optional<ContractAdmin> getAdminById(@PathVariable Integer admin_id)
	{
	return adminService.getAdminById(admin_id);


	}
	
	/*@GetMapping("/contractadmin/{name}")
	public List<ContractAdmin> getAdminByName(@PathVariable String name)
	{
	return adminService.getAdminByName(name);

	}*/	
	
	
	
	@PostMapping("/contractadmin")
	public ContractAdmin saveAdmin(@RequestBody ContractAdmin admin)
	{
		
		return adminService.saveAdmin(admin);
	}
	
	@PutMapping("/contractadmin/{id}")
	public ContractAdmin updateAdmin(@PathVariable("id") Integer id,@RequestBody ContractAdmin admin)
	{
		
		return adminService.updateAdmin(id, admin);
	}
	
	
	@DeleteMapping("/contractadmin/{id}")
	public boolean deleteAdminById(@PathVariable Integer id)
	{
		
		return adminService.deleteAdminById(id);
		
	}

}

