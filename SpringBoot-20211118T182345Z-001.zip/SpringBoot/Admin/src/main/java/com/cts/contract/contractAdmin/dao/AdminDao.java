package com.cts.contract.contractAdmin.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cts.contract.contractAdmin.model.ContractAdmin;

public interface AdminDao extends JpaRepository<ContractAdmin , Integer> {

	
    //List<ContractAdmin> findByName(String name);
	
	List<ContractAdmin> findById(int id);

}
