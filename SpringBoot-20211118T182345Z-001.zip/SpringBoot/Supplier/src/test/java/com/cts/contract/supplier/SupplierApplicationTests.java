package com.cts.contract.supplier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplierApplicationTests {

	@Test
	void contextLoads() {
	}

}
