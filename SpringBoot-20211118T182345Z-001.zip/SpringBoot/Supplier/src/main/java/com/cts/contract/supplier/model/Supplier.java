package com.cts.contract.supplier.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="supplier_table")
public class Supplier {

	@Id
	@GeneratedValue
	private int supplier_id;
	private String supplier_name;
	private String supplier_contactNumber;
	private String supplier_password;
	private String supplier_address;
	private String supplier_mapLocation;
	
	
	public int getSupplier_id() {
		return supplier_id;
	}
	public void setSupplier_id(int supplier_id) {
		this.supplier_id = supplier_id;
	}
	
	public String getSupplier_name() {
		return supplier_name;
	}
	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}
	
	public String getSupplier_contactNumber() {
		return supplier_contactNumber;
	}
	public void setSupplier_contactNumber(String supplier_contactNumber) {
		this.supplier_contactNumber = supplier_contactNumber;
	}
	
	public String getSupplier_password() {
		return supplier_password;
	}
	public void setSupplier_password(String supplier_password) {
		this.supplier_password = supplier_password;
	}
	
	public String getSupplier_address() {
		return supplier_address;
	}
	public void setSupplier_address(String supplier_address) {
		this.supplier_address = supplier_address;
	}
	
	public String getSupplier_mapLocation() {
		return supplier_mapLocation;
	}
	public void setSupplier_mapLocation(String supplier_mapLocation) {
		this.supplier_mapLocation = supplier_mapLocation;
	}
	
	
	
}
