package com.cts.contract.supplier.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.contract.supplier.model.Supplier;


public interface SupplierDao extends JpaRepository<Supplier, Integer>{
	
	//List<Supplier> findByName(String name);
	
	List<Supplier> findById(int id);
	
	
	

}
