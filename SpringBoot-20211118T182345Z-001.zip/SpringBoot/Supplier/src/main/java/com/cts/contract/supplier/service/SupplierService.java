package com.cts.contract.supplier.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.contract.supplier.dao.SupplierDao;
import com.cts.contract.supplier.model.Supplier;




@Service
public class SupplierService {
	
	@Autowired
	SupplierDao supplierDao;	
	
	public SupplierService()
	{
		
	}
	
	
	public List<Supplier> getAllSuppliers()
	{
		
		return supplierDao.findAll();
	}
	
	public Optional<Supplier> getSupplierById(Integer id)
	{
		 return supplierDao.findById(id);
		
	}
	
	//public List<Supplier> getSupplierByName(String name)
	//{
	//	 return supplierDao.findByName(name);
		
	//}
	
	
	
	public Supplier saveSupplier(@RequestBody Supplier supplier)
	{
		return  supplierDao.save(supplier);
	}
	
	public Supplier updateSupplier(Integer id,Supplier supplier)
	{
		List<Supplier> s=getAllSuppliers();
		int position=0;
		for(Supplier sup:s)
		{
			if(sup.getSupplier_id()==id) 
			{
				sup.setSupplier_id(id);
				sup.setSupplier_name(supplier.getSupplier_name());
				sup.setSupplier_contactNumber(supplier.getSupplier_contactNumber());
				sup.setSupplier_password(supplier.getSupplier_password());
				sup.setSupplier_address(supplier.getSupplier_address());
				sup.setSupplier_mapLocation(supplier.getSupplier_mapLocation());
				supplierDao.save(sup);
				s.set(position, sup);
				
				break;
				
			}
			position++;
			
			
		}
		
		return supplier;
	}
	
	public boolean deleteSupplierById(Integer id)
	{
		if(supplierDao.getById(id)!=null) {
			supplierDao.deleteById(id);
		return true;
		}
		else
		{
			return false;
		}
		
	}

}
