package com.cts.contract.supplier.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.contract.supplier.model.Supplier;
import com.cts.contract.supplier.service.SupplierService;



@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SupplierController {
	
	@Autowired
	SupplierService supplierService;	
	
	
	@GetMapping("/suppliers")
	public List<Supplier> getAllSuppliers()
	{		
		return supplierService.getAllSuppliers();
	}
	
	@GetMapping("/suppliers/id/{supplier_id}")
	public Optional<Supplier> getSupplierById(@PathVariable Integer supplier_id)
	{
		return supplierService.getSupplierById(supplier_id);
		
		
	}
	
	//@GetMapping("/suppliers/{name}")
	//public List<Supplier> getSupplierByName(@PathVariable String name)
	//{
	//	return supplierService.getSupplierByName(name);
		
	//}
	
	@PostMapping("/suppliers")
	public Supplier saveSupplier(@RequestBody Supplier supplier)
	{
		
		return supplierService.saveSupplier(supplier);
	}
	
	@PutMapping("/suppliers/{supplier_id}")
	public Supplier updateSupplier(@PathVariable("supplier_id") Integer supplier_id,@RequestBody Supplier supplier)
	{
		
		return supplierService.updateSupplier(supplier_id, supplier);
	}
	
	
	@DeleteMapping("/suppliers/{id}")
	public boolean deleteSupplierById(@PathVariable Integer id)
	{
		
		return supplierService.deleteSupplierById(id);
		
	}

}
