import { Component, OnInit } from '@angular/core';
import { Requirement } from '../requirement';
import { RequirementService } from '../requirement.service';
@Component({
  selector: 'app-sudrequirement',
  templateUrl: './sudrequirement.component.html',
  styleUrls: ['./sudrequirement.component.css']
})
export class SudrequirementComponent implements OnInit {

  //constructor() { }

  ngOnInit(): void {
  }
  requirement: Requirement[]=[];
  constructor(private s:RequirementService) {
	
    s.getAllRequirements().subscribe(data=>{
    this.requirement=data;
    });

  
   }
   deleteRequirement(id:number)
	{
		this.s.deleteRequirement(id).subscribe(data=>{
      alert("Record Deleted successfully");
      location.reload();
		})
	}

}
