import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SudrequirementComponent } from './sudrequirement.component';

describe('SudrequirementComponent', () => {
  let component: SudrequirementComponent;
  let fixture: ComponentFixture<SudrequirementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SudrequirementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SudrequirementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
