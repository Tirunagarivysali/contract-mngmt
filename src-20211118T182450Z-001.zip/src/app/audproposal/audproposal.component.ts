import { Component, OnInit } from '@angular/core';
import { Proposal } from '../proposal';
import { ProposalService } from '../proposal.service';

@Component({
  selector: 'app-audproposal',
  templateUrl: './audproposal.component.html',
  styleUrls: ['./audproposal.component.css']
})
export class AudproposalComponent implements OnInit {



  ngOnInit(): void {
  }
  proposal: Proposal[]=[];
  constructor(private s:ProposalService){
    
    s.getAllProposals().subscribe(data=>{
    this.proposal=data;
    });

  
   }
   public viewSelectedProposal(id:number)
   {

       location.replace("http://localhost:4200/proposal-status");
   } 

}
