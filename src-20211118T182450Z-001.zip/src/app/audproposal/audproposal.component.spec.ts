import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AudproposalComponent } from './audproposal.component';

describe('AudproposalComponent', () => {
  let component: AudproposalComponent;
  let fixture: ComponentFixture<AudproposalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AudproposalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AudproposalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
