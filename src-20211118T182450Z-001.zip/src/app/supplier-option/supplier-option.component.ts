import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-option',
  templateUrl: './supplier-option.component.html',
  styleUrls: ['./supplier-option.component.css']
})
export class SupplierOptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
