import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashadmin',
  templateUrl: './dashadmin.component.html',
  styleUrls: ['./dashadmin.component.css']
})
export class DashadminComponent implements OnInit {

  private addrequirement="http://localhost:4200/addRequirement";
  private viewrequirement="http://localhost:4200/admin-viewRequirement";
  private viewproposals="http://localhost:4200/admin-viewProposal";
  private viewcontracts="http://localhost:4200/admin-viewContract";
  constructor() { }

  ngOnInit(): void {
  }
  public add_req()
  {
    location.replace(this.addrequirement);
  }
  public view_req()
  {
    location.replace(this.viewrequirement);
  }
  public view_pro()
  {
    location.replace(this.viewproposals);
  }
  public view_con()
  {
    location.replace(this.viewcontracts);
  }
}
