import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sudadmin',
  templateUrl: './sudadmin.component.html',
  styleUrls: ['./sudadmin.component.css']
})
export class SudadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
