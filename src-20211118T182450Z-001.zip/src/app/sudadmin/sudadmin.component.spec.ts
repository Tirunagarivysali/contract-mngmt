import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SudadminComponent } from './sudadmin.component';

describe('SudadminComponent', () => {
  let component: SudadminComponent;
  let fixture: ComponentFixture<SudadminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SudadminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SudadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
