import { Component, OnInit } from '@angular/core';
import { Requirement } from '../requirement';
import { RequirementService } from '../requirement.service';

@Component({
  selector: 'app-audrequirement',
  templateUrl: './audrequirement.component.html',
  styleUrls: ['./audrequirement.component.css']
})
export class AudrequirementComponent implements OnInit {



  ngOnInit(): void {
  }
  requirement: Requirement[]=[];
  constructor(private s:RequirementService) {
	
    s.getAllRequirements().subscribe(data=>{
    this.requirement=data;
    });

  
   }
   deleteRequirement(id:number)
	{
		this.s.deleteRequirement(id).subscribe(data=>{
      alert("Record Deleted successfully");
      location.reload();
		})
	}

}
