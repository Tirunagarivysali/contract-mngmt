import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AudrequirementComponent } from './audrequirement.component';

describe('AudrequirementComponent', () => {
  let component: AudrequirementComponent;
  let fixture: ComponentFixture<AudrequirementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AudrequirementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AudrequirementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
