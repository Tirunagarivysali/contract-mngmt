export interface ISupplier
{
    "supplier_id":number;
    "supplier_name":string;
    "supplier_contactNumber":string;
    "supplier_password":string;
    "supplier_address":string;
    "supplier_mapLocation":string;
}
export class Supplier implements ISupplier
{
    "supplier_id":number;
    "supplier_name":string="";
    "supplier_contactNumber":string="";
    "supplier_password":string="";
    "supplier_address":string="";
    "supplier_mapLocation":string="";
}