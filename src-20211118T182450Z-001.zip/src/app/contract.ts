export interface IContract
{
    "contractId":number;
    "contractType":string;
    "contractDuration":string;
    "amenities":string;
    "contract_status":string;

}
export class Contract implements IContract
{
    "contractId":number;
    "contractType":string="";
    "contractDuration":string="";
    "amenities":string="";
    "contract_status":string="";
}