import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Supplier } from './supplier';

@Injectable({
  providedIn: 'root'
})
export class SupplierService {

  constructor(private http:HttpClient) { }
  private url="http://localhost:8081/suppliers";
  supplier: Supplier[]=[];
  s:Supplier=new Supplier;
  public add_supplier(supplier: Supplier)
  {
    return this.http.post(this.url,supplier);
  }
  public getAllSuppliers()
  {
    return this.http.get<Supplier[]>(this.url);
  }
  public deleteSupplier(id:number)
  {
    return this.http.delete<Supplier[]>(this.url+'/'+id);
  }
  public getSupplierById(id:number)
  {
    return this.http.get<Supplier>(this.url+'/id/'+id);
  }

}
