import { Component, OnInit } from '@angular/core';
import { Requirement } from '../requirement';
import { RequirementService } from '../requirement.service';

@Component({
  selector: 'app-requirement',
  templateUrl: './requirement.component.html',
  styleUrls: ['./requirement.component.css']
})
export class RequirementComponent implements OnInit {

  requirement: Requirement=new Requirement;
  constructor(private service:RequirementService) { }

  ngOnInit(): void {
  }

  public add_req()
  {

    if (this.validateRequirement()==false) 
    {
      location.reload();
    } 
    else 
    {
      
    
		this.service.add_requirement(this.requirement).subscribe(data=>{
			alert("Record added successfully");
    })
  }
  }
  exit()
  {
    location.reload();
  }

  public validateRequirement() {
    var x = this.requirement.req_type;
    var y = this.requirement.req_des;
    var z = this.requirement.expected_delivery_date;
    if (x == "")
    {
      alert(" Requirement type can not be empty");
      return false;
    }
    else if(y == "")
    {
      alert("Requirement description can not be empty");
      return false;
    }
    else if(z == "")
    {
      alert("Contract duration can not be empty");
      return false;
    }
    
    else
    {
      return true;
    }
  }
  
  

}
