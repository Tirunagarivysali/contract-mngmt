import { Component, OnInit } from '@angular/core';
import { Contract } from '../contract';
import { ContractService } from '../contract.service';

@Component({
  selector: 'app-amenities',
  templateUrl: './amenities.component.html',
  styleUrls: ['./amenities.component.css'],
})
export class AmenitiesComponent implements OnInit {
  con:Contract[]=[];
  contract: Contract=new Contract;
  constructor(private s:ContractService) 
  {
    s.getAllContracts().subscribe(data=>{
      this.con=data;
      });
  }

  ngOnInit(): void {
  }
  public addamenities()
  {
    if (this.validateAmenities()==false) 
    {
      location.reload();
    } else {
      
    
    this.s.addAmenities(this.contract.contractId,this.contract).subscribe(data=>{
      alert("Amenities updated successfully");
      location.reload();
    })
  }
  }
  public validateAmenities() {
    var x = this.contract.amenities;
    
    if (x == "") {
    
      alert("Amenities can not be empty");
      
      return false;
    }
    
    else
    {  
    return true;  
    }
    
  }

}
