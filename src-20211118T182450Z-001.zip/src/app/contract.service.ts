import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Contract } from './contract';

@Injectable({
  providedIn: 'root'
})
export class ContractService {

  private url="http://localhost:8084/contracts";
  constructor(private http:HttpClient) { }
  contract: Contract[]=[];
  
  public add_contract(contract: Contract)
  {
    return this.http.post(this.url,contract);
  }
  public getAllContracts()
  {
    return this.http.get<Contract[]>(this.url);
  }
  public deleteContract(id:number)
  {
    return this.http.delete<Contract[]>(this.url+'/'+id);
  }
  public addAmenities(id:number,contract:Contract)
  {
    return this.http.put<Contract>(this.url+'/'+id,contract);
    
  }
  public addstatus(id:number,contract:Contract)
  {
    return this.http.put<Contract>(this.url+'/status/'+id,contract);
  }
  public editcontract(id:number,contract:Contract)
  {
    return this.http.put<Contract>(this.url+'/edit/'+id,contract);
  }
}
