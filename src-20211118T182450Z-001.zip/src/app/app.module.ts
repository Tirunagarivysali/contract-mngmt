import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RequirementService } from './requirement.service';
import { RequirementComponent } from './requirement/requirement.component';
import { SudrequirementComponent } from './sudrequirement/sudrequirement.component';
import { HttpClientModule } from '@angular/common//http';
import { FormsModule } from '@angular/forms';
import { SupplierloginComponent } from './supplierlogin/supplierlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { HomepageComponent } from './homepage/homepage.component';
import { SupplierOptionComponent } from './supplier-option/supplier-option.component';
import { ProposalComponent } from './proposal/proposal.component';
import { SudproposalComponent } from './sudproposal/sudproposal.component';
import { ProposalService } from './proposal.service';
import { SupplierComponent } from './supplier/supplier.component';
import { SupplierService } from './supplier.service';

import { SudadminComponent } from './sudadmin/sudadmin.component';
import { SudcontractComponent } from './sudcontract/sudcontract.component';
import { ContractComponent } from './contract/contract.component';
import { ContractService } from './contract.service';
import { DashsupplierComponent } from './dashsupplier/dashsupplier.component';
import { DashadminComponent } from './dashadmin/dashadmin.component';
import { AmenitiesComponent } from './amenities/amenities.component';
import { AudproposalComponent } from './audproposal/audproposal.component';
import { AudcontractComponent } from './audcontract/audcontract.component';
import { StatusproposalComponent } from './statusproposal/statusproposal.component';
import { StatuscontractComponent } from './statuscontract/statuscontract.component';
import { AudrequirementComponent } from './audrequirement/audrequirement.component';
import { SupeditcontractComponent } from './supeditcontract/supeditcontract.component';
@NgModule({
  declarations: [
    AppComponent,
    RequirementComponent,
    SudrequirementComponent,
    SupplierloginComponent,
    AdminloginComponent,
    HomepageComponent,
    SupplierOptionComponent,
    ProposalComponent,
    SudproposalComponent,
    SupplierComponent,
    SudadminComponent,
    SudcontractComponent,
    ContractComponent,
    DashsupplierComponent,
    DashadminComponent,
    AmenitiesComponent,
    AudproposalComponent,
    AudcontractComponent,
    StatusproposalComponent,
    StatuscontractComponent,
    AudrequirementComponent,
    SupeditcontractComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [RequirementService,ProposalService,SupplierService, ContractService],
  bootstrap: [AppComponent]
})
export class AppModule { }
