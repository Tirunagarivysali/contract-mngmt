import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AmenitiesComponent } from './amenities/amenities.component';
import { AudcontractComponent } from './audcontract/audcontract.component';
import { AudproposalComponent } from './audproposal/audproposal.component';
import { AudrequirementComponent } from './audrequirement/audrequirement.component';
import { ContractComponent } from './contract/contract.component';
import { DashadminComponent } from './dashadmin/dashadmin.component';
import { DashsupplierComponent } from './dashsupplier/dashsupplier.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ProposalComponent } from './proposal/proposal.component';
import { RequirementComponent } from './requirement/requirement.component';
import { StatuscontractComponent } from './statuscontract/statuscontract.component';
import { StatusproposalComponent } from './statusproposal/statusproposal.component';
import { SudadminComponent } from './sudadmin/sudadmin.component';
import { SudcontractComponent } from './sudcontract/sudcontract.component';
import { SudproposalComponent } from './sudproposal/sudproposal.component';
import { SudrequirementComponent } from './sudrequirement/sudrequirement.component';
import { SupeditcontractComponent } from './supeditcontract/supeditcontract.component';
import { SupplierOptionComponent } from './supplier-option/supplier-option.component';
import { SupplierComponent } from './supplier/supplier.component';
import { SupplierloginComponent } from './supplierlogin/supplierlogin.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'supplierLogin', component: SupplierloginComponent },
  { path: 'adminLogin', component: AdminloginComponent },
  { path: 'home', component:HomepageComponent },
  { path: 'supplieroption',component:SupplierOptionComponent},
  { path:'addRequirement', component:RequirementComponent},
  { path:'viewRequirement', component:SudrequirementComponent},
  { path:'addProposal', component:ProposalComponent},
  { path:'viewProposal', component:SudproposalComponent},
  { path:'addContract',component:ContractComponent},
  { path:'viewContract',component:SudcontractComponent},
  { path:'viewAdmin',component:SudadminComponent},
  { path:'addSupplier',component:SupplierComponent},
  { path:'dashboard-admin',component:DashadminComponent},
  { path:'dashboard-supplier',component:DashsupplierComponent},
  { path:'addAmenities',component:AmenitiesComponent},
  { path:'admin-viewContract',component:AudcontractComponent},
  { path:'admin-viewProposal',component:AudproposalComponent},
  { path:'contract-status',component:StatuscontractComponent},
  { path:'proposal-status',component:StatusproposalComponent},
  { path:'admin-viewRequirement',component:AudrequirementComponent},
  { path:'edit-contract',component:SupeditcontractComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
