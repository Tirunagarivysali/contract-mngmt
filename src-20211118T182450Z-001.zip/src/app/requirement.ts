export interface IRequirement
{
    "req_id":number
    "req_type":string,
    "req_des":string,
    "expected_delivery_date":string
}
export class Requirement implements IRequirement
{
	"req_id":number;
    "req_type":string="";
    "req_des":string="";
    "expected_delivery_date":string="";
}