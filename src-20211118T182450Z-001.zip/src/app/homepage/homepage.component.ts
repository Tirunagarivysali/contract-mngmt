import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  public supplieroption()
  {
    location.replace("http://localhost:4200/supplieroption");
  }
  public adminlogin()
  {
    location.replace("http://localhost:4200/adminLogin");
  }
}
