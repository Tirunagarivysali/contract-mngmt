export interface IProposal
{
    "proposal_id":number;
    "requirement_id":number;
    "proposal_date":string;
    "quotation":string;
    "supplier_name":string;
    "proposal_status":string;
}
export class Proposal implements IProposal
{
    "proposal_id":number;
    "requirement_id":number;
    "proposal_date":string="";
    "quotation":string="";
    "supplier_name":string="";
    "proposal_status":string="";
}