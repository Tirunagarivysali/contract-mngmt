import { Component, OnInit } from '@angular/core';
import { Contract } from '../contract';
import { ContractService } from '../contract.service';

@Component({
  selector: 'app-sudcontract',
  templateUrl: './sudcontract.component.html',
  styleUrls: ['./sudcontract.component.css']
})
export class SudcontractComponent implements OnInit {

  ngOnInit(): void {
  }
  contract: Contract[]=[];
  constructor(private s:ContractService){
	
    s.getAllContracts().subscribe(data=>{
    this.contract=data;
    });

  
   }
   deleteContract(id:number)
	{
		this.s.deleteContract(id).subscribe(data=>{
      alert("Record Deleted successfully");
      location.reload();
		})
	} 

}
