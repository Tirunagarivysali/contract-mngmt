import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SudcontractComponent } from './sudcontract.component';

describe('SudcontractComponent', () => {
  let component: SudcontractComponent;
  let fixture: ComponentFixture<SudcontractComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SudcontractComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SudcontractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
