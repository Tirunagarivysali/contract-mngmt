import { Component, OnInit } from '@angular/core';
import { Proposal } from '../proposal';
import { ProposalService } from '../proposal.service';

@Component({
  selector: 'app-sudproposal',
  templateUrl: './sudproposal.component.html',
  styleUrls: ['./sudproposal.component.css']
})
export class SudproposalComponent implements OnInit {
  router: any;

  

  ngOnInit(): void {
  }
  proposal: Proposal[]=[];
  constructor(private s:ProposalService){
    
    s.getAllProposals().subscribe(data=>{
    this.proposal=data;
    });

  
   }
   deleteProposal(id:number)
	{
		this.s.deleteProposal(id).subscribe(data=>{
      alert("Record Deleted successfully");
      location.reload();
		})
  }

}
