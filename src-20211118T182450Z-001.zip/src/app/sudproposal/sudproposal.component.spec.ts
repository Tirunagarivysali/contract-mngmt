import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SudproposalComponent } from './sudproposal.component';

describe('SudproposalComponent', () => {
  let component: SudproposalComponent;
  let fixture: ComponentFixture<SudproposalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SudproposalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SudproposalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
