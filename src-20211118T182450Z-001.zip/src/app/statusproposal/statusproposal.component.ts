import { Component, OnInit } from '@angular/core';
import { Proposal } from '../proposal';
import { ProposalService } from '../proposal.service';

@Component({
  selector: 'app-statusproposal',
  templateUrl: './statusproposal.component.html',
  styleUrls: ['./statusproposal.component.css']
})
export class StatusproposalComponent implements OnInit {
  prop:Proposal[]=[];
  eid:number=0;
  constructor(private s:ProposalService) { 

    s.getAllProposals().subscribe(data=>{
      this.prop=data;
      });
      
  
  }
  proposal:Proposal=new Proposal;
  ngOnInit(): void {
  }
  public addproposalstatus()
  {
    if (this.validateStatus()==false) {
      location.reload();
      
    } else {
      
    }
    this.s.addpstatus(this.proposal.proposal_id,this.proposal).subscribe(data=>{
      alert("Status updated successfully");
      location.reload();
		})
  }
  exit()
  {
    location.reload();
  }
  public validateStatus() {
    var x = this.proposal.proposal_status;
    
    if (x == "") {
    
      alert("Status can not be empty");
      
      return false;
    }
    
    else
    {  
    return true;  
    }
    
  }
}
