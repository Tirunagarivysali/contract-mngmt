import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatusproposalComponent } from './statusproposal.component';

describe('StatusproposalComponent', () => {
  let component: StatusproposalComponent;
  let fixture: ComponentFixture<StatusproposalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatusproposalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StatusproposalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
