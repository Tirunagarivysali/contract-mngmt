import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common//http';
import { Requirement } from './requirement';
import {HttpHeaders} from '@angular/common/http'
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class RequirementService {
  private url="http://localhost:8082/requirements";
  requirement: Requirement[]=[];
  constructor(private http:HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }


  public add_requirement(requirement: Requirement)
  {
    return this.http.post(this.url,requirement);
  }
  public getAllRequirements()
  {
    return this.http.get<Requirement[]>(this.url);
  }
  public deleteRequirement(id:number)
{
	return this.http.delete<Requirement[]>(this.url+'/'+id);
}
 /* add_requirement(requirement:Requirement):Observable<Requirement[]>
{
	return this.http.post<Requirement[]>(this.url,requirement,this.httpOptions);
}*/
}
