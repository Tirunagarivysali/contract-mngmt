import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatuscontractComponent } from './statuscontract.component';

describe('StatuscontractComponent', () => {
  let component: StatuscontractComponent;
  let fixture: ComponentFixture<StatuscontractComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatuscontractComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StatuscontractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
