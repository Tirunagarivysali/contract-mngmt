import { convertActionBinding } from '@angular/compiler/src/compiler_util/expression_converter';
import { Component, OnInit } from '@angular/core';
import { Contract } from '../contract';
import { ContractService } from '../contract.service';

@Component({
  selector: 'app-statuscontract',
  templateUrl: './statuscontract.component.html',
  styleUrls: ['./statuscontract.component.css'],
  

})
export class StatuscontractComponent implements OnInit {
con:Contract[]=[];
  constructor(private s:ContractService) {
    s.getAllContracts().subscribe(data=>{
      this.con=data;
      });
   }
  
  contract:Contract=new Contract;
  ngOnInit(): void {
  }
 
  public addcontractstatus()
  {
    if (this.validateStatus()==false) 
    {
      location.reload();  
    } else {
      
    }
    this.s.addstatus(this.contract.contractId,this.contract).subscribe(data=>{
      alert("Status updated successfully");
      location.reload();
		})
  }
  exit()
  {
    location.reload();
  }
  public validateStatus() {
    var x = this.contract.contract_status;
    
    if (x == "") {
    
      alert("Status can not be empty");
      
      return false;
    }
    
    else
    {  
    return true;  
    }
    
  }
}
