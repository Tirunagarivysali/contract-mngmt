import { Component, OnInit } from '@angular/core';
import { Contract } from '../contract';
import { ContractService } from '../contract.service';

@Component({
  selector: 'app-supeditcontract',
  templateUrl: './supeditcontract.component.html',
  styleUrls: ['./supeditcontract.component.css']
})
export class SupeditcontractComponent implements OnInit {
  con:Contract[]=[];
  constructor(private s:ContractService) {
    s.getAllContracts().subscribe(data=>{
      this.con=data;
      });
   }
   contract:Contract=new Contract;
  ngOnInit(): void {
  }
  public editcontractstatus()
  {
    this.s.editcontract(this.contract.contractId,this.contract).subscribe(data=>{
      alert("Contract edited successfully");
      location.reload();
		})
  } public exit()
  {
    location.reload();
  }

}
