import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupeditcontractComponent } from './supeditcontract.component';

describe('SupeditcontractComponent', () => {
  let component: SupeditcontractComponent;
  let fixture: ComponentFixture<SupeditcontractComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SupeditcontractComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SupeditcontractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
