import { Component, OnInit } from '@angular/core';
import { Proposal } from '../proposal';
import { ProposalService } from '../proposal.service';
import { Requirement } from '../requirement';
import { RequirementService } from '../requirement.service';

@Component({
  selector: 'app-proposal',
  templateUrl: './proposal.component.html',
  styleUrls: ['./proposal.component.css']
})
export class ProposalComponent implements OnInit {

  constructor(private service:ProposalService,private s:RequirementService) {
    s.getAllRequirements().subscribe(data=>{
      this.requirement=data;
      });
   }
  proposal: Proposal=new Proposal;
  requirement: Requirement[]=[];
  
  ngOnInit(): void {
  }

  public add_proposal()
  {
    if (this.validateProposal()==false) 
    {
      location.reload();  
    } else 
    {
      
    
		this.service.add_proposal(this.proposal).subscribe(data=>{
      alert("Record added successfully");
      location.reload();
    })
  }
  }
  exit()
  {
    location.reload();
  }

  public validateProposal() {
    var x = this.proposal.requirement_id;
    var y = this.proposal.proposal_date; 
    var z = this.proposal.quotation;
    if (x == null)
    {
      alert(" Requirement ID can not be empty");
      return false;
    }
    else if (isNaN(x))
    {
      alert("Requirement ID must be a number");
      return false;
    }
    else if(y == "")
    {
      alert("Proposal date can not be empty");
       return false;
    }
    else if(z == "")
    {
      alert("Quotation can not be empty");
       return false;
    }
    else
    {
      return true;
    }
  }
  
  

}
