export interface IAdmin
{
    "admin_id":number;
    "admin_name":string;
    "admin_contact":string;
    "admin_password":string;
    "admin_address":string;
}
export class Admin implements IAdmin
{
    "admin_id":number;
    "admin_name":string="";
    "admin_contact":string="";
    "admin_password":string="";
    "admin_address":string="";
}