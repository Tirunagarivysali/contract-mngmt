import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Admin } from './admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http:HttpClient) { }
  private url="http://localhost:8080/contractadmin";
  admin: Admin[]=[];
  public add_admin(admin: Admin)
  {
    return this.http.post(this.url,admin);
  }
  public getAllAdmins()
  {
    return this.http.get<Admin[]>(this.url);
  }
  public deleteAdmin(id:number)
  {
    return this.http.delete<Admin[]>(this.url+'/'+id);
  }
  public getAdminById(id:number)

  {

    return this.http.get<Admin>(this.url+'/id/'+id);

  }
}
