import { Component, OnInit } from '@angular/core';
import { Supplier } from '../supplier';
import { SupplierService } from '../supplier.service';

@Component({
  selector: 'app-supplier',
  templateUrl: './supplier.component.html',
  styleUrls: ['./supplier.component.css']
})
export class SupplierComponent implements OnInit {

 
  constructor(private service:SupplierService) { }
  supplier: Supplier=new Supplier;
  ngOnInit(): void {
  }
  public add_supplier()
  {
    console.log(this.supplier);
		this.service.add_supplier(this.supplier).subscribe(data=>{
      alert("Record added successfully");
      location.reload();
		})
  }
  exit()
  {
    location.reload();
  }

}
