import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common//http';

import { Proposal } from './proposal';

@Injectable({
  providedIn: 'root'
})
export class ProposalService {
  private url="http://localhost:8083/proposal";
  constructor(private http:HttpClient) { }
  proposal: Proposal[]=[];
  
  public add_proposal(proposal: Proposal)
  {
    return this.http.post(this.url,proposal);
  }
  public getAllProposals()
  {
    return this.http.get<Proposal[]>(this.url);
  }
  public deleteProposal(id:number)
  {
    return this.http.delete<Proposal[]>(this.url+'/'+id);
  }
  public addpstatus(id:number,proposal:Proposal)
  {
    return this.http.put<Proposal>(this.url+'/status/'+id,proposal);
  }
}
