import { Component, OnInit } from '@angular/core';
import { Contract } from '../contract';
import { ContractService } from '../contract.service';

@Component({
  selector: 'app-contract',
  templateUrl: './contract.component.html',
  styleUrls: ['./contract.component.css']
})
export class ContractComponent implements OnInit {

  constructor(private service:ContractService) { }
  contract: Contract=new Contract;
  ngOnInit(): void {
  }
  public add_contract()
  {
    if (this.validateContract()==false) 
    {
      location.reload();  
    } else {
      
    
		this.service.add_contract(this.contract).subscribe(data=>{
      alert("Record added successfully");
      location.reload();
    })
  }
  }
  exit()
  {
    location.reload();
  }

  public validateContract() {
    var x = this.contract.contractType;
    var y = this.contract.contractDuration;
    if (x == "")
    {
    alert(" Contract type must be filled out");
    return false;
    }
    else if(y == "")
    {
    alert("Contract duration must be filled out");
    return false;
    }
    else
    {
    return true;
    }
  }
}
