import { Component, OnInit } from '@angular/core';
import { Supplier } from '../supplier';
import { SupplierService } from '../supplier.service';

@Component({
  selector: 'app-supplierlogin',
  templateUrl: './supplierlogin.component.html',
  styleUrls: ['./supplierlogin.component.css']
})
export class SupplierloginComponent implements OnInit {

  supplier: Supplier=new Supplier;
  constructor(private s:SupplierService) 
  {
    
   }
   

  ngOnInit(): void {
  }
  exit()
  {
    location.reload();
  }
  
  public verify()
	{
    if (this.validateSupplierLogin()==false) {
      location.reload()
      
    } else {
      
    
    this.s.getSupplierById(this.supplier.supplier_id).subscribe(data=>{
      
      console.log(data.supplier_password);
      if(this.supplier.supplier_password==data.supplier_password)
      {
        alert("Login Successful");
        location.replace("/dashboard-supplier");
      }
      else
      {
        alert("Incorrect UserID/Password");
        location.reload();
      }
      });
    }
	}
  public validateSupplierLogin() {
    var x = this.supplier.supplier_id;
    var y = this.supplier.supplier_password; 
    if (x == null) {
    
      alert("Supplier ID can not be empty");
      return false;
    }
    else if (isNaN(x))
    {  
    alert("Supplier ID must be a number");
    return false;
    }
    else if(y == "") 
    {
      alert("Supplier Password can not be empty");
      return false;
    }
    else
    {  
    return true;  
    }
    
  }
}
