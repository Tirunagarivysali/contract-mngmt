import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  constructor(private s:AdminService) 
  {
    
   }
  admin:Admin=new Admin;
  ngOnInit(): void {
  }
  exit()
  {
    location.reload();
  }
  public verify()

  {
    
    if (this.validateAdminLogin()==false) {
      location.reload();
    } else {
      
    
    this.s.getAdminById(this.admin.admin_id).subscribe(data=>{
      console.log(data.admin_password);
      if(this.admin.admin_password==data.admin_password)
      {
        alert("Login Successful");
        location.replace("/dashboard-admin");
      }
      else
      {
        alert("Incorrect UserID/Password");
        location.reload();
      }

      });
    }
  }
  public validateAdminLogin() {
    var x = this.admin.admin_id;
    var y = this.admin.admin_password; 
    if ( x == null) 
    {  
      alert("Admin ID can not be empty");
      return false;
    }
    else if (isNaN(x))
    {  
    alert("Admin ID must be a number");
    return false;
    }
    else if (y =="") {
      alert("Admin Password can not be empty");
    
      return false;
    }
     
    else{  
    return true; 
    }
    
  }

}

