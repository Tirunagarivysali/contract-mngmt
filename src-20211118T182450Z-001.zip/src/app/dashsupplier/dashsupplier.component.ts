import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashsupplier',
  templateUrl: './dashsupplier.component.html',
  styleUrls: ['./dashsupplier.component.css']
})
export class DashsupplierComponent implements OnInit {

  constructor() { }
  private addproposal="http://localhost:4200/addProposal";
  private viewproposal="http://localhost:4200/viewProposal";
  private addcontract="http://localhost:4200/addContract";
  private viewcontract="http://localhost:4200/viewContract";
  private addamenities="http://localhost:4200/addAmenities";
  private viewreq="http://localhost:4200/viewRequirement";
  private editcon="http://localhost:4200/edit-contract";
  ngOnInit(): void {
  }
  public create_proposal()
  {
    location.replace(this.addproposal);
  }
  public view_proposal()
  {
    location.replace(this.viewproposal);
  }
  public create_contract()
  {
      location.replace(this.addcontract);
  }
  public set_amenities()
  {
      location.replace(this.addamenities);
  }
  public view_contract()
  {
    location.replace(this.viewcontract);
  }
  public view_requirement()
  {
    location.replace(this.viewreq);
  }
  public edit_contract()
  {
    location.replace(this.editcon);
  }
  
}
