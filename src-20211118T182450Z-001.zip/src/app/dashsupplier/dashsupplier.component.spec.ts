import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashsupplierComponent } from './dashsupplier.component';

describe('DashsupplierComponent', () => {
  let component: DashsupplierComponent;
  let fixture: ComponentFixture<DashsupplierComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashsupplierComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DashsupplierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
