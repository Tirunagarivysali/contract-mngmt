import { viewClassName } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Contract } from '../contract';
import { ContractService } from '../contract.service';
import { StatuscontractComponent } from '../statuscontract/statuscontract.component';

@Component({
  selector: 'app-audcontract',
  templateUrl: './audcontract.component.html',
  styleUrls: ['./audcontract.component.css']
})
export class AudcontractComponent implements OnInit {



  ngOnInit(): void {
  }
  contract: Contract[]=[];
  constructor(private s:ContractService){
	    s.getAllContracts().subscribe(data=>{
    this.contract=data;
    });

   }
   public viewSelectedContract()
	{
      location.replace("http://localhost:4200/contract-status");
	} 

}