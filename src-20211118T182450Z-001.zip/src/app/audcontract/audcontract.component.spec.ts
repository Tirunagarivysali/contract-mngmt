import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AudcontractComponent } from './audcontract.component';

describe('AudcontractComponent', () => {
  let component: AudcontractComponent;
  let fixture: ComponentFixture<AudcontractComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AudcontractComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AudcontractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
